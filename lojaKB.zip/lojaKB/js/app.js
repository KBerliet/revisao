
import {
  cadastrarProduto,
  listarProdutos,
  buscarProduto,
  editarProduto,
  excluirProduto
} from './produtos.js';

function executarAcao(acao, dados) {
  switch (acao) {
    case 'cadastrar':
      cadastrarProduto(...dados);
      break;
    case 'listar':
      listarProdutos(dados);
      break;
    case 'buscar':
      buscarProduto(dados);
      break;
    case 'editar':
      editarProduto(...dados);
      break;
    case 'excluir':
      excluirProduto(dados);
      break;
    default:
      console.error(`Ação "${acao}" não reconhecida.`);
  }
}

executarAcao('cadastrar', ['Camisa Verde', 'Camisa de algodão verde', 29.90, 'roupas']);
executarAcao('listar');
executarAcao('buscar', 'Camisa Verde');