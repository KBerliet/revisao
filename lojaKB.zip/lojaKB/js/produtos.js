function cadastrarProduto(nome, descricao, preco, categoria) {
}

function listarProdutos(categoria) {
}

function buscarProduto(termoBusca) {
}

function editarProduto(codigoProduto, novosDados) {
}

function excluirProduto(codigoProduto) {
}
